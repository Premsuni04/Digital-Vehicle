
from django.urls import path
from djproject_app1 import views

urlpatterns =[
    
    path('',views.home), 
    path('display/',views.display,name='display'),
    path('submit/', views.submit,name='submit'),
    
    
]