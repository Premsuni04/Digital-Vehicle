from django.shortcuts import render
from django.http import HttpResponse


# Create your views here.
def home(request):
    return HttpResponse("Welcome to my project")


def display(request):
    data = ['athira','bincy','usha']
    return render(request,"sample.html",{'key':data})



def submit(request):
    if request.method == 'POST':
        username=request.POST.get('user_name')
        password=request.POST.get('pass_word')
        return HttpResponse(username+password)





    
