from django.urls import path
from djproject_app2 import views


urlpatterns =[

   path('Login/', views.User_Login, name= 'User_Login'),
   path('vehicle/', views.User_Vehicle, name ='User_Vehicle'),
   path('home/',views.home,name='home'),
   path('user/',views.User_Page, name = 'User_Page'),
   path('signup/',views.User_Register,name='User_Register'),
   path('police/',views.Police_Login, name = 'Police_Login'),
   path('rto/', views.RTO_Login, name='RTO_Login'),
   path('rto1/',views.RTO_Page, name ='RTO_Page'),
   path('Vehicle2/',views.all_Vehicle, name ='all_Vehicle'),
   path('Police1/',views.Police_Page, name = 'Police_Page')
   

        
]        