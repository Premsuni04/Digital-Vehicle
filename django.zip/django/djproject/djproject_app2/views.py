from django.shortcuts import redirect,render
from django.http import HttpResponse
from django.contrib.auth import authenticate
from django.contrib import messages
from . models import Login
from . models import Vehicle
from . models import Register
from . models import RTO

# Create your views here.

def home(request):
    return render(request,"index.html")

def User_Login(request):
    if request.POST:
        user_name = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username=user_name, password=password)
        if user is not None:
            Login(request, user)
            return redirect('User_Page')
        else:
            messages.success(request, ("There Was An Error Logging In, Try Again...."))
            return redirect('User_Login')
    else:
       return render(request, "User_Login.html")
       

   # user_name=None
   # if request.method=='POST':
   #    user_name = request.POST.get('user_name')
   #    password = request.POST.get('password')
   #    if Login.objects.filter(user_name = user_name, password = password).exists():
   #       return redirect('index.html')
   #    else:
   #       return render(request,'User_Page.html',{'error':user_name})
   # return render(request,'User_Login.html')
   
 
 
def User_Vehicle(request):
   if request.method == 'POST':
      
      Owner_Name = request.POST.get('Owner_Name')
      License_Reg_Date = request.POST.get('License_Reg_Date')
      License_Exp_Date = request.POST.get('License_Exp_Date')
      Insurance_Number = request.POST.get('Insurance_Number')
      RC_Book = request.POST.get('RC_Book')
      Vehicle_no = request.POST.get('Vehicle_no')
      Model = request.POST.get('Model')
      RTO_Branch = request.POST.get('RTO_Branch')
      Vehicle_obj = Vehicle()
      
      Vehicle_obj.Owner_Name = Owner_Name
      Vehicle_obj.License_Reg_Date = License_Reg_Date
      Vehicle_obj.License_Exp_Date = License_Exp_Date
      Vehicle_obj.Insurance_Number = Insurance_Number
      Vehicle_obj.RC_Book = RC_Book
      Vehicle_obj.Vehicle_no = Vehicle_no
      Vehicle_obj.Model = Model
      Vehicle_obj.RTO_Branch = RTO_Branch
      Vehicle_obj.save()
      return redirect('User_Page')
   return render(request, 'User_Vehicle.html')




def User_Page(request):
   return render(request,"User_Page.html")


def User_Register(request):
    if request.method == 'POST':
       
       Email = request.POST.get('email')
       Phone = request.POST.get('phone_no')
       Address = request.POST.get('address')
       Pin_code = request.POST.get('pin_code')
       user_name = request.POST.get('user_name')
       password = request.POST.get('password')
       Login_obj = Login()
       Register_obj = Register()
       if Login.objects.filter(user_name =user_name):
         return HttpResponse("<script>alert('User Id Already exists');window.location='/User_Register'</script>")
       else:
       
        Login_obj.user_name = user_name
        Login_obj.password = password
        Register_obj.email = Email
        Register_obj.phone = Phone
        Register_obj.address = Address
        Register_obj.pin_code = Pin_code
        Register_obj.Login = Login_obj
        Login_obj.save()
        Register_obj.save()
        return redirect('User_Login') 
    return render(request,'User_Register.html')
 
 
def Police_Login(request):
   if request.method=='POST':
      username = request.POST['username']
      password = request.POST['password']

      user = authenticate(request, username=username, password=password)
      if user is not None:
         Login(request, user)
         return redirect('Police_Page')
      else:
         messages.success(request, ("There Was An Error Logging In, Try Again...."))
         return redirect('Police_Login')
   else:   
     return render(request,"Police_Login.html")

def RTO_Login(request):
   if request.method=='POST':
      user_name = request.POST['username']
      password = request.POST['password']

      user = authenticate(request, username=user_name, password=password)
      if user is not None:
         Login(request, user)
         return redirect('RTO_Page')
      else:
         messages.success(request, ("There Was An Error Logging In, Try Again...."))
         return redirect('RTO_Login')
   else:   
     return render(request,"RTO_Login.html")
 
# def RTO_register(request):
#     if request.method == 'POST':
       
#        Name = request.POST.get('Name')
#        Id_Number = request.POST.get('Id_Number')
#        RTO_Branch = request.POST.get('RTO_Branch')
#        Login_obj = Login()
#        RTO_obj = RTO()
#        if Login.objects.filter(Name = Name):
#          return HttpResponse("<script>alert('User Id Already exists');window.location='/RTO_register'</script>")
#        else:
       
#         Login_obj.user_name = Name
#         RTO_obj.Id_Number = Id_Number
#         RTO_obj.RTO_Branch = RTO_Branch
#         RTO_obj.Login = Login_obj
#         Login_obj.save()
#         RTO_obj.save()
#         return redirect('RTO_Login') 
#     return render(request,'RTO_register.html')

def RTO_Page(request):
   return render(request,"RTO_Page.html")

def all_Vehicle(request):
   Vehicle_list = Vehicle.objects.all()
   print(request.method)
   if request.method == 'POST':
      if 'reject' in request.POST :
         Vehicle.status = 'reject'
         
      else:
         Vehicle.status = 'accept'
         
         Vehicle.save()
   return render(request,"Vehicle.html",{'Vehicle_list': Vehicle_list})

def Police_Page(request):
   return render(request,"Police_Page.html")

def accept(request):
   return render(request)




   
 
        
      
 
      
      
      
   
      
   




    
