from django.db import models
from django.db.models.deletion import CASCADE
from django.db.models.fields import CharField
from django.db.models.fields.related import ForeignKey

# Create your models here.

class Login(models.Model):
   user_name = models.CharField(max_length=20)
   password = models.CharField(max_length=20)
   

   
class Vehicle(models.Model):
   Owner_Name = models.CharField(max_length=20)
   License_Reg_Date = models.CharField(max_length=20)
   License_Exp_Date = models.CharField(max_length=20)
   Insurance_Number = models.CharField(max_length=20)
   RC_Book = models.CharField(max_length=20)
   Vehicle_no = models.CharField(max_length=20)
   Model = models.IntegerField()
   RTO_Branch = models.CharField(max_length=20)
   
   
   def __str__(self):
      return self.Owner_Name
   
class Register(models.Model):
   email = models.CharField(max_length=50)
   phone = models.CharField(max_length=20)
   address = models.CharField(max_length=50)
   pin_code = models.IntegerField()
   Login = models.ForeignKey(Login, on_delete=CASCADE)
   
   
class RTO(models.Model):
   RTO_Address = models.CharField(max_length=100)
   Rto_Code = models.CharField(max_length=50)
   RTO_Branch = models.CharField(max_length=50)
   RTO_PhoneNo = models.CharField(max_length=20)
   User_name = models.CharField(max_length=20)
   password = models.CharField(max_length=20)
   

class Police(models.Model):
   Name = models.CharField(max_length=20)
   Phone = models.CharField(max_length=20)
   Station_Branch = models.CharField(max_length=20)
   Address = models.CharField(max_length=50)
   Pin_Code = models.CharField(max_length=20)
   username = models.CharField(max_length=20)
   password = models.CharField(max_length=20)
   

    
   

   
   

   
     
   
   
   
   

   