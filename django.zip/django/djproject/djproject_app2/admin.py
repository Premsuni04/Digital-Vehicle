from django.contrib import admin
from .models import Register
from .models import RTO
from .models import Police

# Register your models here.
admin.site.register(Register)
admin.site.register(RTO)
admin.site.register(Police)
