from django import forms 
from django.forms import ModelForm
from .models import Registration
from .models import Login
from .models import Vehicle
from .models import Register
from .models import RTO


class Registration_form(ModelForm):
    class Meta:
        model = Registration
        fields = '__all__'
        
class Login_form(ModelForm):
    class Meta:
        model = Login
        fields = '__all__'
        
class Vehicle_form(ModelForm):
    class Meta:
        model = Vehicle
        fields = '__all__'
        
class Register_form(ModelForm):
    class Meta:
        model = Register
        fields = '__all__'
        
class RTO_form(ModelForm):
    class Meta:
        model = RTO
        fields = '__all__'