from django.apps import AppConfig


class DjprojectApp2Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'djproject_app2'
